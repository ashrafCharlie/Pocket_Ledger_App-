enum TransactionType {
  income,
  expense,
}